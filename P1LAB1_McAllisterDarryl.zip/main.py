user_name = input()

print("Hello",user_name,"and welcome to CS Online!") 