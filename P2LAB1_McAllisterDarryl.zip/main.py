gas_mile = float(input())
gas_cost = float(input())

per_gal = gas_mile / gas_cost

value1 = 20 / per_gal
value2 = 75 / per_gal
value3 = 500 / per_gal

print(f'{value1:.2f} {value2:.2f} {value3:.2f}')